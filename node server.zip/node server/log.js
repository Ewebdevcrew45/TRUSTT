module.exports = require('buyan').createLogger({name: 'Trustt app'});
